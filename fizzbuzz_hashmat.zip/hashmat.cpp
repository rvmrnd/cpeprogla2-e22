#include <iostream>
#include <cstdlib>
using namespace std;

int main(){
	int x, y, diff;
	
	cin >> x >> y;
	diff = x - y;
	
	cout << abs(diff);
	
	return 0;
}
