#include <iostream>
#include <math.h>
#include <ctime>
#include <cstdlib>

using namespace std;

void problem2(){
	int uniques[10];
	int num;
	int min = 1;
	int max = 20;
	srand( (unsigned)time( NULL )); 
	for(int i =0; i<10; i++){
		num = min + (rand() % (max - min + 1));
		
		for(int j=0; j<10; j++){		
			if(num == uniques[j]){
				num = min + (rand() % (max - min + 1));
			}	
			else{
				uniques[i] = num;
			}
		}
	}

	for(int i=0; i<10; i++){
		cout << uniques[i]<<" ";
	}
}

main(){
	cout << "Unique numbers: ";
	problem2();
	
	return 0;
}
