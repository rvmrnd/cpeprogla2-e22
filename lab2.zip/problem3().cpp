#include <iostream>

using namespace std;

int max(int a, int b){
	if (a>b)
		cout << a;
	else
		cout << b;
}

main(){
	double a, b;
	cout << "Input two numbers: ";
	cin >> a >> b;
	
	cout << endl << "The greater number is: " << max(a,b);	
	return 0;
	
}

